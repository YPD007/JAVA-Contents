package service;

public class AdditionService {
    public static String doAddition(Double n1,Double n2)
    {
        return "Your Answer Is:"+String.valueOf((n1+n2));
    }

}
